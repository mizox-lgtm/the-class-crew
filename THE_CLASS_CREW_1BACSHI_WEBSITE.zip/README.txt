THE CLASS CREW — 1BACSH-I
==========================

This is a ready-to-preview static website.

FASTEST WAY TO VIEW:
1. Extract the ZIP file.
2. Open the folder `class_crew_site`.
3. Double-click `index.html` to open it in Chrome.

HOW TO PUBLISH FOR FREE WITH GITHUB PAGES:
1. Create/sign in to a GitHub account.
2. Create a new public repository, e.g. `the-class-crew`.
3. Upload BOTH `index.html` and the `assets` folder (keep the same folder structure).
4. In the repository, open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
6. Wait for the published URL shown in the Pages section.

IMPORTANT:
- This website is not online until you publish it.
- External PDF/video links are linked to their source websites; they are not rehosted.
- Some links are general or may match a different stream. Check them with your teacher before relying on them.
- The “recent resources” section is a starting template; replace/add materials as you collect them.
